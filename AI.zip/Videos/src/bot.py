import telebot  #trong pip pyTelegramBotAPI
from config import TELEGRAM_API_KEY
from handler.command_handler import send_welcome
from handler.message_handler import handle_message

# Khởi tạo bot Telegram
bot = telebot.TeleBot(TELEGRAM_API_KEY)

# Xử lý lệnh /start và /help
@bot.message_handler(commands=['start', 'help']) # ham message_handler nhan ham command_handler la doi so
def command_handler(message):
    send_welcome(bot, message)

# Xử lý tin nhắn người dùng
@bot.message_handler(func=lambda message: True)
def message_handler(message):
    handle_message(bot, message)

if __name__ == "__main__":
    print("Bot is running...")
    bot.polling()
