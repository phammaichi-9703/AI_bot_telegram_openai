def send_welcome(bot, message):
    bot.reply_to(message, "Welcome! This bot uses webhook instead of polling.")
